# Bootcamp Frontend G14

* git status
* git add index.html
* git commit -m "Mi primera página"
* git add -A
* git log
* git log --oneline
* git log --oneline --graph
* git show <hash>
* git remote add origin https://github.com/victorvzn/bootcamp-frontend-g14.git
* git branch -M main
* git push -u origin main
* git remote remove origin
* git status
* git status
